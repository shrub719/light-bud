export function sampleFunction() {
  console.log('content script - sampleFunction() called from another module');
}
